create DATABASE `Form_Data_Barang`; 
USE `Form_Data_Barang`; 
DROP TABLE IF EXISTS `data_barang_toko_1`; 
create TABLE `data barang toko 1` ( 
`id` int(12) NOT NULL AUTO_INCREMENT, 
`nama_barang` varchar(255) DEFAULT NULL, 
PRIMARY KEY (`id`) 
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1; 
