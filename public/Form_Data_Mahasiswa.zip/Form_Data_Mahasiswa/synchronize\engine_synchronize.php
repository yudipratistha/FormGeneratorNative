<?php
    include_once __DIR__ . '/../vendor/autoload.php';

    set_time_limit(0);
    $sleep_time = 2;
    while(true){
        sleep($sleep_time);
        try{    
            function getClient()
            {
                $client = new Google_Client();
                $client->setApplicationName('Google Drive API PHP Quickstart');
                $client->setScopes(Google_Service_Drive::DRIVE_METADATA_READONLY);
                $client->setAuthConfig('credentials.json');
                $client->setAccessType('offline');
                $client->setPrompt('select_account consent');

                // Load previously authorized token from a file, if it exists.
                // The file token.json stores the user's access and refresh tokens, and is
                // created automatically when the authorization flow completes for the first
                // time.
                $tokenPath = 'token.json';
                if (file_exists($tokenPath)) {
                    $accessToken = json_decode(file_get_contents($tokenPath), true);
                    $client->setAccessToken($accessToken);
                }

                // If there is no previous token or it's expired.
                if ($client->isAccessTokenExpired()) {
                    // Refresh the token if possible, else fetch a new one.
                    if ($client->getRefreshToken()) {
                        $client->fetchAccessTokenWithRefreshToken($client->getRefreshToken());
                    } else {
                        // Request authorization from the user.
                        $authUrl = $client->createAuthUrl();
                        printf("Open the following link in your browser:\n%s\n", $authUrl);
                        print 'Enter verification code: ';
                        $authCode = trim(fgets(STDIN));

                        // Exchange authorization code for an access token.
                        $accessToken = $client->fetchAccessTokenWithAuthCode($authCode);
                        $client->setAccessToken($accessToken);

                        // Check to see if there was an error.
                        if (array_key_exists('error', $accessToken)) {
                            throw new Exception(join(', ', $accessToken));
                        }
                    }
                    // Save the token to a file.
                    if (!file_exists(dirname($tokenPath))) {
                        mkdir(dirname($tokenPath), 0700, true);
                    }
                    file_put_contents($tokenPath, json_encode($client->getAccessToken()));
                }
                return $client;
            }


            // Get the API client and construct the service object.
            $client = getClient();
            $service = new Google_Service_Drive($client);



            $app = new DropboxApp($app_key, $app_secret, $access_token); 
            $dropbox = new Dropbox($app);     
            foreach($syncs as $sync){
                $path = "/".$project_name."/".$sync["folder"]."/unsynchronized";
                $listFile = $dropbox->listFolder($path);
                if(empty($listFile->getItems()->first())) echo "No unsynchronized data on ".$sync["folder"]."\n";
                else{
                    $first_file_name = $listFile->getItems()->first()->getName();
                    $file_download = $dropbox->download($path."/".$first_file_name);
                    $file_content = json_decode($file_download->getContents(),true);
    
                    $attributes = ""; 
                    $values = "";
                    foreach($sync['attribute'] as $i => $attr){
                        $attributes = $attributes.$attr;
                        if($i < count($sync['attribute'])-1) $attributes = $attributes.",";
                    }
                    $j = 0;
                    foreach($file_content as $i => $data){
                        $data = str_replace('"', '\"', $data);
                        $values = $values.'"'.$data.'"';
                        if($j < count($file_content)-1) $values = $values.", ";
                        $j++;
                    }
                    $query = "INSERT INTO ".$sync["table"]."(".$attributes.") VALUES(".$values.")";
                    $conn = new PDO("mysql:host=$server;dbname=$db", $user, $pass);
                    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                    $sql = $conn->prepare($query);
                    $sql->execute();
    
                    $move_path = "/".$project_name."/".$sync["folder"]."/synchronized";
                    $move = $dropbox->move($path."/".$first_file_name, $move_path."/".$first_file_name, true);
                    echo $query."\n";
                }
            }
        }catch(Exception $e){   
            echo("Connection failed: " . $e->getMessage()."\n");
        }
    }
?>