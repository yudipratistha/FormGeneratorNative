<?php $oauth_credentials = __DIR__ ."/google/oauth-credentials.json";include_once __DIR__ . '/google/autoload.php';$folderFormName = "Form Data Mahasiswa"; session_start();$redirect_uri = 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['PHP_SELF'];$client = new Google_Client();$client->setAuthConfig($oauth_credentials);$client->setRedirectUri($redirect_uri);$client->addScope("https://www.googleapis.com/auth/drive");$service = new Google_Service_Drive($client);if (isset($_REQUEST['logout'])) {unset($_SESSION['upload_token']);}if (isset($_GET['code'])) {$token = $client->fetchAccessTokenWithAuthCode($_GET['code']);$client->setAccessToken($token);$_SESSION['upload_token'] = $token;header('Location: ' . filter_var($redirect_uri, FILTER_SANITIZE_URL));}if (!empty($_SESSION['upload_token'])) {$client->setAccessToken($_SESSION['upload_token']);if ($client->isAccessTokenExpired()) {unset($_SESSION['upload_token']);}}else {$authUrl = $client->createAuthUrl();}if ($_SERVER['REQUEST_METHOD'] == 'POST' && $client->getAccessToken() && isset($_POST["values"])) {$file_name = "data".".json"; $values = $_POST["values"]; $myJSON = json_encode($values); $fp = fopen($file_name, "w"); fwrite($fp, $myJSON); fclose($fp); $optParams = array('pageSize' => 1,'fields' => 'nextPageToken, files','q' => "name = '".$folderFormName."' and mimeType = 'application/vnd.google-apps.folder'");$searchFolder = $service->files->listFiles($optParams);foreach ($searchFolder->getFiles() as $file) {$folderSearchId = $file->getId();}$file = new Google_Service_Drive_DriveFile();$file->setParents([$folderSearchId]);$content = file_get_contents('data.json');$result2 = $service->files->create($file,array('data' => $content, 'mimeType' => 'application/json', 'uploadType' => 'multipart'));}?> <html><head><link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous"><script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script><script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script><script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script><body><?php if (isset($authUrl)): ?><div class="request"><a class='login' href='<?= $authUrl ?>'>Loggin</a></div><?php else: ?><form class="form-border form-horizontal" method="POST">
          <fieldset>
  <div id="legend" class="" data-toggle="popover" aria-describedby="popover26653">
      <legend class="legend-border-title">Form Data Mahasiswa</legend>
  </div>
          <div class="form-group" data-toggle="popover">

      <!-- Text input-->
      <label class="col-md-6 control-label" for="input01">Nama</label>
      
        <div class="col-md-6" id="attribute">
        <input type="text" placeholder="Yudi..." class="form-control input-md" name="values[nama]" id="attr">
        <p class="help-block"></p>
      
      </div>
      
    </div>

    <div class="form-group" data-toggle="popover" aria-describedby="popover813797">

      <!-- Text input-->
      <label class="col-md-6 control-label" for="input01">Alamat</label>
      
        <div class="col-md-6" id="attribute">
        <input type="text" placeholder="Jl. Nangka..." class="form-control input-md" name="values[alamat]" id="attr">
        <p class="help-block"></p>
      
      </div>
      
    </div>

    <div class="form-group" data-toggle="popover" aria-describedby="popover400250">

      <!-- Text input-->
      <label class="col-md-6 control-label" for="input01">Nomor Telepon</label>
      <div class="col-md-6">
        <input type="text" placeholder="081238...." class="form-control input-md" name="values[notelp]" id="attr">
        <p class="help-block"></p>
      </div>
    </div>

    <div class="form-group" data-toggle="popover" aria-describedby="popover80042">

      <!-- Text input-->
      <label class="col-md-6 control-label" for="input01">NIM</label>
      <div class="col-md-6">
        <input type="text" placeholder="1605551013" class="form-control input-md" name="values[nim]" id="attr">
        <p class="help-block"></p>
      </div>
    </div>

    <div class="form-group" data-toggle="popover" aria-describedby="popover92614">

      <!-- Text input-->
      <label class="col-md-6 control-label" for="input01">Tempat, Tanggal Lahir</label>
      <div class="col-md-6">
        <input type="text" placeholder="Denpasar, 03 Desember 1997" class="form-control input-md" name="values[ttl]" id="attr">
        <p class="help-block"></p>
      </div>
    </div>

    

    

    <div class="form-group" data-toggle="popover" aria-describedby="popover497138">
      <label class="col-md-6 control-label">Checkboxes</label>
      <div class="col-md-6">
      <!-- Multiple Checkboxes -->
      <label class="checkbox">
        <input class="" type="checkbox" value="Option one" name="values[checkbox][]" id-attr="attr" id="attr">
        Option one
      </label>
      <label class="checkbox">
        <input class="" type="checkbox" value="gfhf" name="values[checkbox][]" id-attr="attr" id="attr">
        gfhf
      </label>
      <label class="checkbox">
        <input class="" type="checkbox" value="uijh" name="values[checkbox][]" id-attr="attr" id="attr">
        uijh
      </label>
  </div>
    </div><div class="form-group" aria-describedby="popover700026">
    <!-- Button -->
    <div class="col-md-4">
      <button class="btn btn-primary">Save</button>
    </div>
  </div>

    </fieldset>
      </form><?php endif ?></body></head></html>